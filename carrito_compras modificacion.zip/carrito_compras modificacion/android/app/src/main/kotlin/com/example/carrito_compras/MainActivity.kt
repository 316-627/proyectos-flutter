package com.example.carrito_compras

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

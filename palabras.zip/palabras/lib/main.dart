import 'package:english_words/english_words.dart';
import 'package:flutter/material.dart';
import 'contenido/my_app.dart';
import 'contenido/random_words.dart';

void main() {
  runApp(const MyApp());
}
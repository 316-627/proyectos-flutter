import 'package:flutter/material.dart';

class MyTile extends StatelessWidget {
  final int count;

  const MyTile({Key? key, required this.count});


  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Container(
        height: 100,
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage('image/pic${count +5}.jpg'),
                alignment: Alignment.topLeft),
            borderRadius: BorderRadius.circular(8),
            color: Colors.blueGrey[100]
        ),

        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (count == 0)...[
                const Text('Perro raza criolla, tiene 1 año y brinda mucho amor'
              ),
              ]else if (count == 1)...[
                const Text('Gato raza Americano de pelo corto, con 4 meses'
              ),
              ]else if (count == 2)...[
                const Text('Perro enrazado con pitbul muy atento al peligro con 2 años'
              ),
              ]else if (count == 3)...[
                const Text('Gata raza criolla con 2 meses de nacido, muy cariñoso'
              ),
              ]else if (count == 4)...[
                const Text('Perrito con 5 meses muy cariños raza Westiepoo'
              ),
              ]else if (count == 5)...[
                const Text('Gatito con 6 meses de raza criolla muy jugueton'
              ),
              ]else if (count == 6)...[
                const Text('Perro criollo con 8 meses muy consentido'
              ),
              ]else if (count == 7)...[
                const Text('Gato con 7 meses raza bombay muy poco cariñoso'
              ),
              ]else if (count == 8)...[
                const Text('Perro raza golden con 4 meses y muy imperactivo y cariñoso'
              ),
              ]else if (count == 9)...[
                const Text('Gato raza americano de pelo corto con 1 año muy extrovertido'
              ),
              ]
          ],
        ),
      ),
    );
  }
}
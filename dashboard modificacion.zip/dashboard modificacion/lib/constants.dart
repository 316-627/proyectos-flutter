import 'package:flutter/material.dart';

var defaulBackgrondColor = Colors.grey[300];
var appBarColor = Colors.blueGrey[200];
var myAppBar = AppBar(
  backgroundColor: appBarColor,
  title: const Text('Tu Nuevo Compañero de Vida'),
  centerTitle: false,
);
var drawerTextColor = TextStyle(
  color: Colors.white
);
var tilePadding = const EdgeInsets.only(left: 8.0, right: 8, top: 8);
var myDrawer = Drawer(
  backgroundColor: Colors.blueGrey[200],
  elevation: 0,
  child: Column(
    children: [
      DrawerHeader(
          child: (
          CircleAvatar(
            radius: 70,
            backgroundImage: NetworkImage("image/pic0.jpg"),
          )
          ),
      ),
      Padding(
        padding: tilePadding,
        child: ListTile(
          leading: const Icon(Icons.home),
          title: Text(
            'I N I C I O',
            style: drawerTextColor,
          ),
        ),
      ),
      Padding(
        padding: tilePadding,
        child: ListTile(
          leading: const Icon(Icons.settings),
          title: Text(
            'A J U S T E S',
            style: drawerTextColor,
          ),
        ),
      ),
      Padding(
        padding: tilePadding,
        child: ListTile(
          leading: const Icon(Icons.info),
          title: Text(
            'A Y U D A',
            style: drawerTextColor,
          ),
        ),
      ),
      Padding(
        padding: tilePadding,
        child: ListTile(
          leading: const Icon(Icons.logout),
          title: Text(
            'S A L I R',
            style: drawerTextColor,
          ),
        ),
      ),
    ],
  ),
);

package com.example.loguin_modificacion

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
